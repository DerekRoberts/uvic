public class ExpressionTreeException extends RuntimeException {
  public ExpressionTreeException( String msg ) {
  	super( msg );
  }
  public ExpressionTreeException( ) {
  	super ();
  }
}
